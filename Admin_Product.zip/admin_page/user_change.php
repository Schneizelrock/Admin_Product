<?php
include 'class/class.db.user.php';
if(isset($_GET['id'])){
  $tb_user = new DB_User();
  $user_arr = $tb_user->get_user($_GET['id']);
  $user = $user_arr[0]['user'];
  $password = $user_arr[0]['password'];
  $level = $user_arr[0]['level'];
  $email = $user_arr[0]['email'];
  $fullname = $user_arr[0]['fullname'];
  $address = $user_arr[0]['address'];
  $gender = $user_arr[0]['gender'];
  $birthday = $user_arr[0]['birthday'];


    if (isset($_POST['edit-bt'])) {
      $id = (isset($_POST['id'])) ?$_POST['id']: -1;
      $user = (isset($_POST['user'])) ?$_POST['user']: "";
      $password = (isset($_POST['password'])) ?$_POST['password']: "";
      $level = (isset($_POST['level'])) ?$_POST['level']: "";
      $email = (isset($_POST['email'])) ?$_POST['email']: "";
      $fullname = (isset($_POST['fullname'])) ?$_POST['fullname']: "";
      $address = (isset($_POST['address'])) ?$_POST['address']: "";
      $gender = (isset($_POST['gender'])) ?$_POST['gender']: "";
      $birthday = (isset($_POST['birthday'])) ?$_POST['birthday']: "";
      $result = $tb_user->edit_user($id, $user, $password, $level, $email, $fullname, $address, $gender, $birthday);

      if ($result) {
        echo'<script>alert("Edit success"); window.location="user_show.php"</script>';
      }else{
        echo'<script>alert("Edit not success"); window.location="user_show.php"</script>';
        }
      }
}
?>





<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>User Edit</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
     <div class="container-admin">
       <div id="header-admin">
         <img src="img/login-bg.jpg">
      </div>
      <div id="content-admin">
        <div class="menu">
          <ul>
            <li><a href="user_show.php">User Management</a></li>
            <li><a href="product_show.php">Product Management</a></li>
          </ul>
        </div>
      <div class="main-content">
        <div class="label">
          LIST USER
        </div>
      <div class="main-content-insert">
        <form name="insert_user" method="post">
          <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
          <div class="label-detail">User</div>
          <div class="text-detail">
            <input type="text" name="user" class="text-width" value="<?php echo $user; ?>">
          </div>
          <div class="label-detail">Password</div>
          <div class="text-detail">
            <input type="password" name="password" class="text-width" value="<?php echo $password; ?>">
          </div>
          <div class="label-detail">Level</div>
          <div class="text-level">
            <select name="level" class="text-width1" value="<?php echo $level; ?>">
              <option value="1">1</option>
              <option value="2">2</option>
            </select>
          </div>
          <div class="label-detail">Email</div>
          <div class="text-detail">
            <input type="email" name="email" class="text-width" value="<?php echo $email; ?>">
          </div>
          <div class="label-detail">fullname</div>
          <div class="text-detail">
            <input type="text" name="fullname" class="text-width" value="<?php echo $fullname; ?>">
          </div>
          <div class="label-detail">Address</div>
          <div class="text-detail">
            <input type="text" name="address" class="text-width" value="<?php echo $address; ?>">
          </div>
          <div class="label-detail">Gender</div>
          <div class="text-gender">
            <select name="gender" class="text-width1" value="<?php echo $gender; ?>">
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="label-detail">Birthday</div>
          <div class="text-detail">
            <input type="text" name="birthday" class="text-width1" value="<?php echo $birthday; ?>">
          </div>

             <div class="button-insert">
               <input type="submit" name="edit-bt" value="EDIT" class="button-width">
             </div>


        </form>
      </div>
    </div>
  </div>
  <div id="footer-admin">
    <img src="img/login-bg.jpg">
  </div>
    </div>


  </body>
</html>
