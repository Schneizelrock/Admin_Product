<?php

class DB
{
  private $link;
  function __construct()
  {
    $this->link = mysqli_connect('localhost', 'root', '1234', 'db_user');
  }
  public function db_query($query){
    $result = mysqli_query($this->link, $query);
    return $result;
  }
  public function db_fetch($result){
    $row = mysqli_fetch_assoc($result);
    return $row;
  }
}
