<?php
include 'class/class.db.user.php';
$tb_product = new DB_User();
$product_arr = $tb_product->get_product();

$user_html = "";
$limit = 2;
$numrecord = count($product_arr);

if ($numrecord == 0) {
  $user_html = 'Empty database ...<a href="user_insert.php">Insert</a>';
}else{
  $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
  $total_page = ceil($numrecord/$limit);
  $start1 = ($current_page-1)*$limit;
  $product_arr1 = $tb_product->get_product_limit($start1,$limit);
  $user_html = '<table width="100%" id="table_user" cellspacing="0"
   cellpadding="10">
                        <tr>
                            <th>Name</th>
                            <th>Code</th>
                            <th>Cost</th>
                            <th>Status</th>
                            <th>Weight</th>
                            <th>Species</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>IMG</th>
                            <th>Type</th>
                            <th colspan="2">&nbsp;</th>
                        </tr>';

     foreach ($product_arr1 as $item) {
       $user_html .= '<tr>';
       $user_html .= '<td>'.$item['name'].'</td>';
       $user_html .= '<td>'.$item['code'].'</td>';
       $user_html .= '<td>'.$item['cost'].'</td>';
       $user_html .= '<td>'.$item['status'].'</td>';
       $user_html .= '<td>'.$item['weight'].'</td>';
       $user_html .= '<td>'.$item['species'].'</td>';
       $user_html .= '<td>'.$item['age'].'</td>';
       $user_html .= '<td>'.$item['gender'].'</td>';
       $user_html .= '<td>'.$item['img'].'</td>';
       $user_html .= '<td>'.$item['type'].'</td>';
       $user_html .= '<td><a href="product_change.php?id='.$item['id_product'].'"
        title="Edit"><img src="img/edit-icon.png"></a></td>';
      $user_html .= '<td><a href="product_delete.php?id='.$item['id_product'].'"
         title="Delete"><img src="img/delete-icon.png"></a></td>';
         $user_html .='</tr>';
     }
     $user_html .='</table>';
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Show page</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
    <div class="container-admin">
      <div id="header-admin">
          <img src="img/login-bg.jpg">
      </div>
        <div id="content-admin">
          <div class="menu">
            <ul>
              <li><a href="user_show.php">User Management</a></li>
              <li><a href="product_show.php">Product Management</a></li>
            </ul>
          </div>
          <div class="main-content">
            <div class="label">
              LIST PRODUCT
            </div>
            <div class="listuser">
              <div class="insert">
                <a href="product_insert.php" title="Insert"><img src="img/insert.png"></a>
              </div>
              <div class="list-content">
                <?php echo $user_html; ?>
            </div>
            <div class="page">
              <div class="page-center">
                <ul>
                  <?php
                  if ($current_page > 1 && $total_page > 1) {
                    echo '<li><a href="product_show.php?page='.($current_page-1).'">Prev</a></li>';
                  }
                  for ($i = 1; $i <= $total_page ; $i++) {
                    if ($i == $current_page) {
                      echo '<li><span class="current-page">'.$i.'</span></li>';
                    }else{
                      echo '<li><a href="product_show.php?page='.$i.'">'.$i.'</a></li>';
                    }
                  }
                  if ($current_page < $total_page && $total_page > 1) {
                    echo '<li><a href="product_show.php?page='.($current_page+1).'">Next</a></li>';

                  }
                     ?>
        </div>
      </div>
        <div id="footer-admin">
          <img src="img/login-bg.jpg">
        </div>
      </div>


  </body>
</html>
