<?php
include 'class/class.db.user.php';
$tb_user = new DB_User();
$user_arr = $tb_user->get_user();

$user_html = "";
$limit = 2;
$numrecord = count($user_arr);

if ($numrecord == 0) {
  $user_html = 'Empty database ...<a href="user_insert.php">Insert</a>';
}else{
  $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
  $total_page = ceil($numrecord/$limit);
  $start1 = ($current_page-1)*$limit;
  $user_arr1 = $tb_user->get_user_limit($start1,$limit);
  $user_html = '<table width="100%" id="table_user" cellspacing="0"
   cellpadding="10">
                        <tr>
                            <th>User</th>
                            <th>Password</th>
                            <th>Level</th>
                            <th>Email</th>
                            <th>Full name</th>
                            <th>Address</th>
                            <th>Gender</th>
                            <th>Birthday</th>
                            <th colspan="2">&nbsp;</th>
                        </tr>';

     foreach ($user_arr1 as $item) {
       $user_html .= '<tr>';
       $user_html .= '<td>'.$item['user'].'</td>';
       $user_html .= '<td>'.$item['password'].'</td>';
       $user_html .= '<td>'.$item['level'].'</td>';
       $user_html .= '<td>'.$item['email'].'</td>';
       $user_html .= '<td>'.$item['fullname'].'</td>';
       $user_html .= '<td>'.$item['address'].'</td>';
       $user_html .= '<td>'.$item['gender'].'</td>';
       $user_html .= '<td>'.$item['birthday'].'</td>';
       $user_html .= '<td><a href="user_change.php?id='.$item['id_user'].'"
        title="Edit"><img src="img/edit-icon.png"></a></td>';
      $user_html .= '<td><a href="user_delete.php?id='.$item['id_user'].'"
         title="Delete"><img src="img/delete-icon.png"></a></td>';
         $user_html .='</tr>';
     }
     $user_html .='</table>';
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Show page</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
    <div class="container-admin">
      <div id="header-admin">
          <img src="img/login-bg.jpg">
      </div>
        <div id="content-admin">
          <div class="menu">
            <ul>
              <li><a href="user_show.php">User Management</a></li>
              <li><a href="product_show.php">Product Management</a></li>
            </ul>
          </div>
          <div class="main-content">
            <div class="label">
              LIST USER
            </div>
            <div class="listuser">
              <div class="insert">
                <a href="user_insert.php" title="Insert"><img src="img/insert.png"></a>
              </div>
              <div class="list-content">
                <?php echo $user_html; ?>
            </div>
            <div class="page">
              <div class="page-center">
                <ul>
                  <?php
                  if ($current_page > 1 && $total_page > 1) {
                    echo '<li><a href="user_show.php?page='.($current_page-1).'">Prev</a></li>';
                  }
                  for ($i = 1; $i <= $total_page ; $i++) {
                    if ($i == $current_page) {
                      echo '<li><span class="current-page">'.$i.'</span></li>';
                    }else{
                      echo '<li><a href="user_show.php?page='.$i.'">'.$i.'</a></li>';
                    }
                  }
                  if ($current_page < $total_page && $total_page > 1) {
                    echo '<li><a href="user_show.php?page='.($current_page+1).'">Next</a></li>';

                  }
                     ?>
        </div>
      </div>
        <div id="footer-admin">
          <img src="img/login-bg.jpg">
        </div>
      </div>


  </body>
</html>
