<?php
include 'class/class.db.user.php';
if (isset($_POST['insert-bt'])) {
  $tb_product = new DB_User();
  $name = (isset($_POST['name'])) ?$_POST['name']: "";
  $code = (isset($_POST['code'])) ?$_POST['code']: "";
  $cost = (isset($_POST['cost'])) ?$_POST['cost']: "";
  $status = (isset($_POST['status'])) ?$_POST['status']: "";
  $weight = (isset($_POST['weight'])) ?$_POST['weight']: "";
  $species = (isset($_POST['species'])) ?$_POST['species']: "";
  $age = (isset($_POST['age'])) ?$_POST['age']: "";
  $gender = (isset($_POST['gender'])) ?$_POST['gender']: "";
  $img = (isset($_POST['img'])) ?$_POST['img']: "";
  $type = (isset($_POST['type'])) ?$_POST['type']: "";
  $result = $tb_product->insert_product($name, $code, $cost, $status, $weight, $species, $age, $gender, $img, $type);

  if ($result) {
    echo'<script>alert("Insert success"); window.location="product_show.php"</script>';
  }else{
    echo'<script>alert("Insert not success"); window.location="product_show.php"</script>';
    }
  }
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Product Insert</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
     <div class="container-admin">
       <div id="header-admin">
         <img src="img/login-bg.jpg">
      </div>
      <div id="content-admin">
        <div class="menu">
          <ul>
            <li><a href="user_show.php">User Management</a></li>
            <li><a href="product_show.php">Product Management</a></li>
          </ul>
        </div>
      <div class="main-content">
        <div class="label">
          INSERT PRODUCT
        </div>
      <div class="main-content-insert">
        <form name="insert_user" method="post">
          <div class="label-detail">Name</div>
          <div class="text-detail">
            <input type="text" name="name" class="text-width">
          </div>
          <div class="label-detail">Model</div>
          <div class="text-detail">
            <input type="text" name="code" class="text-width">
          </div>
          <div class="label-detail">Cost</div>
          <div class="text-detail">
            <input type="text" name="cost" class="text-width">
          </div>

          <div class="label-detail">Status</div>
          <div class="text-gender">
            <select name="status" class="text-width1">
              <option value="InStock">InStock</option>
              <option value="Out of Stock">Out of Stock</option>
            </select>
          </div>

          <div class="label-detail">Weight</div>
          <div class="text-detail">
            <input type="text" name="weight" class="text-width">
          </div>

          <div class="label-detail">Species</div>
          <div class="text-gender">
            <select name="species" class="text-width1">
              <option value="Bullet">Bullet</option>
              <option value="Classic">Classic</option>
              <option value="Thunderbird">Thunderbird</option>
              <option value="Interceptor">Interceptor</option>
              <option value="Himalayan">Himalayan</option>
              <option value="Continental GT 650">Continental GT 650</option>
            </select>
          </div>

          <div class="label-detail">Age</div>
          <div class="text-detail">
            <input type="text" name="age" class="text-width">
          </div>

          <div class="label-detail">Color</div>
          <div class="text-gender">
            <select name="gender" class="text-width1">
              <option value="Redditch Red">Redditch Red</option>
              <option value="Redditch Blue">Redditch Blue</option>
              <option value="Black">Black</option>
              <option value="Ash">Ash</option>
              <option value="Gunmetal Grey">Gunmetal Grey</option>
              <option value="Chestnut">Chestnut</option>
              <option value="Redditch Green">Redditch Green</option>
              <option value="Lagoon">Lagoon</option>
              <option value="Silver">Silver</option>
              <option value="Stormrider Sand">Stormrider Sand</option>
            </select>
          </div>

          <div class="label-detail">IMG</div>
          <div class="text-detail">
            <input type="text" name="img" class="text-width">
          </div>

          <div class="label-detail">Type</div>
          <div class="text-gender">
            <select name="type" class="text-width1">
              <option value="One-Seater">One-Seater</option>
              <option value="Two-Seater">Two-Seater</option>
            </select>
          </div>

             <div class="button-insert">
               <input type="submit" name="insert-bt" value="INSERT" class="button-width">
             </div>


        </form>
      </div>
    </div>
  </div>
  <div id="footer-admin">
    <img src="img/login-bg.jpg">
  </div>
    </div>


  </body>
</html>
