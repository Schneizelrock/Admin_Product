<?php
include 'class/class.db.user.php';
if (isset($_POST['insert-bt'])) {
  $tb_user = new DB_User();
  $user = (isset($_POST['user'])) ?$_POST['user']: "";
  $password = (isset($_POST['password'])) ?$_POST['password']: "";
  $level = (isset($_POST['level'])) ?$_POST['level']: "";
  $email = (isset($_POST['email'])) ?$_POST['email']: "";
  $fullname = (isset($_POST['fullname'])) ?$_POST['fullname']: "";
  $address = (isset($_POST['address'])) ?$_POST['address']: "";
  $gender = (isset($_POST['gender'])) ?$_POST['gender']: "";
  $birthday = (isset($_POST['birthday'])) ?$_POST['birthday']: "";
  $result = $tb_user->insert_user($user, $password, $level, $email, $fullname, $address, $gender, $birthday);

  if ($result) {
    echo'<script>alert("Insert success"); window.location="user_show.php"</script>';
  }else{
    echo'<script>alert("Insert not success"); window.location="user_show.php"</script>';
    }
  }
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>User Insert</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
     <div class="container-admin">
       <div id="header-admin">
         <img src="img/login-bg.jpg">
      </div>
      <div id="content-admin">
        <div class="menu">
          <ul>
            <li><a href="">User Management</a></li>
            <li><a href="">Tab new</a></li>
          </ul>
        </div>
      <div class="main-content">
        <div class="label">
          INSERT USER
        </div>
      <div class="main-content-insert">
        <form name="insert_user" method="post">
          <div class="label-detail">User</div>
          <div class="text-detail">
            <input type="text" name="user" class="text-width">
          </div>
          <div class="label-detail">Password</div>
          <div class="text-detail">
            <input type="password" name="password" class="text-width">
          </div>
          <div class="label-detail">Level</div>
          <div class="text-level">
            <select name="level" class="text-width1">
              <option value="1">1</option>
              <option value="2">2</option>
            </select>
          </div>
          <div class="label-detail">Email</div>
          <div class="text-detail">
            <input type="email" name="email" class="text-width">
          </div>
          <div class="label-detail">fullname</div>
          <div class="text-detail">
            <input type="text" name="fullname" class="text-width">
          </div>
          <div class="label-detail">Address</div>
          <div class="text-detail">
            <input type="text" name="address" class="text-width">
          </div>
          <div class="label-detail">Gender</div>
          <div class="text-gender">
            <select name="gender" class="text-width1">
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="label-detail">Birthday</div>
          <div class="text-detail">
            <input type="text" name="birthday" class="text-width1">
          </div>

             <div class="button-insert">
               <input type="submit" name="insert-bt" value="INSERT" class="button-width">
             </div>


        </form>
      </div>
    </div>
  </div>
  <div id="footer-admin">
    <img src="img/login-bg.jpg">
  </div>
    </div>


  </body>
</html>
