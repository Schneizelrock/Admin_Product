-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2019 at 05:48 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_user`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `cost` int(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `weight` varchar(20) DEFAULT NULL,
  `species` varchar(30) DEFAULT NULL,
  `age` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `img` varchar(80) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`id_product`, `name`, `code`, `cost`, `status`, `weight`, `species`, `age`, `gender`, `img`, `type`) VALUES
(1, 'Royal Enfield', 'Bullet 350', 4000, 'InStock', '183 kg', 'Bullet', 'New', 'Redditch Red', 'img/Royal-Enfield-Continental-GT-UK.jpg', 'One-Seater'),
(2, 'Royal Enfield', 'Classic 500', 3500, 'InStock', '186 kg', 'Bullet', 'New', 'Redditch Red', 'img/royal-enfield-thunderbird.jpg', 'Two-Seater');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(10) UNSIGNED NOT NULL,
  `user` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `level` int(2) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `user`, `password`, `level`, `email`, `fullname`, `address`, `gender`, `birthday`) VALUES
(1, 'admin', 'admin', 1, 'adminemail@gmail.com', 'Amdin Name1 ', 'address1', 'Male', '1998-04-02'),
(3, 'user1', 'user1', 2, 'user1email@gmail.com', 'User Name1', 'address2', 'Male', '1997-05-03'),
(4, 'user2', 'user2', 2, 'user2email@gmail.com', 'User Name2', 'address3', 'Female', '1998-06-04'),
(5, 'user5', 'user5', 2, 'user4email@gmail.com', 'User Name', 'address5', 'Female', '1996-12-05'),
(6, 'user6', 'user6', 2, 'user6email@gmail.com', 'User Name6', 'address6', 'Female', '1986-11-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `id_product` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
