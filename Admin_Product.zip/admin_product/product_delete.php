<?php
include 'class/class.db.user.php';
if (isset($_GET['id'])) {
  $tb_product = new DB_User();
  $id = $_GET['id'];
  $result = $tb_product->delete_product($id);
  if ($result) {
    echo'<script>alert("Delete success"); window.location="product_show.php"</script>';
  }else{
    echo'<script>alert("Delete not success"); window.location="product_show.php"</script>';

  }
}
 ?>
