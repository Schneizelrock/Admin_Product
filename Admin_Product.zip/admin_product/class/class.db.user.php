<?php
 include 'class.db.php';
 global $conn;

 class DB_User extends DB
 {
   function __construct()
   {
     parent::__construct();
   }

   public function get_user($id = -1){
     $query = "select * from tb_user";
     if ($id != -1) {
       $query .= " where id_user=$id";
      }
      $result = $this->db_query($query);
      $user = array();
      $i = 0;
      while ($row = $this->db_fetch($result)) {
        $user[$i++] = $row;
      }
      return $user;
   }

   public function get_product($id = -1){
     $query = "select * from tb_product";
     if ($id != -1) {
       $query .= " where id_product=$id";
      }
      $result = $this->db_query($query);
      $user = array();
      $i = 0;
      while ($row = $this->db_fetch($result)) {
        $user[$i++] = $row;
      }
      return $user;
   }
   public function get_user_limit($start, $limit) {
     $query = "select * from tb_user limit $start,$limit";
     $result = $this->db_query($query);
     $user = array();
     $i = 0;
     while ($row = $this->db_fetch($result)) {
       $user[$i++] = $row;
     }
     return $user;
   }
   public function get_product_limit($start, $limit) {
     $query = "select * from tb_product limit $start,$limit";
     $result = $this->db_query($query);
     $user = array();
     $i = 0;
     while ($row = $this->db_fetch($result)) {
       $user[$i++] = $row;
     }
     return $user;
   }

   public function insert_user($user, $password, $level, $email, $fullname, $address, $gender, $birthday){
     $query = "insert into tb_user(user, password, level, email, fullname, address, gender, birthday) values('$user', '$password', '$level', '$email', '$fullname', '$address', '$gender', '$birthday')";
     $result = $this->db_query($query);
     return $result;
   }
     public function insert_product($name, $code, $cost, $status, $weight, $species, $age, $gender, $img, $type){
     $query = "insert into tb_product(name, code, cost, status, weight, species, age, gender, img, type) values('$name', '$code', '$cost', '$status', '$weight', '$species', '$age', '$gender', '$img', '$type')";
     $result = $this->db_query($query);
     return $result;
   }

   public function edit_user($id, $user, $password, $level, $email, $fullname, $address, $gender, $birthday){
     $query = "update tb_user set user = '$user', password = '$password', level = '$level', email = '$email', fullname = '$fullname', address = '$address', gender = '$gender', birthday = '$birthday' where id_user=$id";
     $result = $this->db_query($query);
     return $result;

 }

 public function edit_product($id, $name, $code, $cost, $status, $weight, $species, $age, $gender, $img, $type){
   $query = "update tb_product set name = '$name', code = '$code', cost = '$cost', status = '$status', weight = '$weight', species = '$species', age = '$age', gender = '$gender', img = '$img', type = '$type' where id_product=$id";
   $result = $this->db_query($query);
   return $result;

}

  public function delete_user($id){
    $query = "delete from tb_user where id_user=$id";
  $result = $this->db_query($query);
  return $result;
 }

 public function delete_product($id){
   $query = "delete from tb_product where id_product=$id";
 $result = $this->db_query($query);
 return $result;
}




}
