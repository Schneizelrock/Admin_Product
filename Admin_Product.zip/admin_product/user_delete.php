<?php
include 'class/class.db.user.php';
if (isset($_GET['id'])) {
  $tb_user = new DB_User();
  $id = $_GET['id'];
  $result = $tb_user->delete_user($id);
  if ($result) {
    echo'<script>alert("Delete success"); window.location="user_show.php"</script>';
  }else{
    echo'<script>alert("Delete not success"); window.location="user_show.php"</script>';

  }
}
 ?>
